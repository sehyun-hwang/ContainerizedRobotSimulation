pip3.8 install -t site-packages -U 'nbconvert<6'
#jupyter nbconvert --to script hello.ipynb